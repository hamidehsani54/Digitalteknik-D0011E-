# D0011E - Laboration 1
The lab specification is both on Canvas and in this repository. It is important that you make sure that all the questions in the lab specification has been answered in your README (this file). You don't have to use the same structure as we've created, but if you change it make it clear.

## Answers

### Question 1
Review `bcdcheck2.vhd`. Based on your understanding of the code, what will the output of each signal be given a specific input? Fill in the table below.

|  Input | max | min | even | lo3 | noBCD |
|:------:|:---:|:---:|:----:|:---:|:-----:|
|    0   |  0  |  1  |  1   |  1  |   0   |
|    1   |  0  |  0  |  0   |  1  |   0   |
|    2   |  0  |  0  |  1   |  1  |   0   |
|    3   |  0  |  0  |  0   |  0  |   0   |
|    4   |  0  |  0  |  1   |  0  |   0   |
|    5   |  0  |  0  |  0   |  0  |   0   |
|    6   |  0  |  0  |  1   |  0  |   0   |
|    7   |  0  |  0  |  0   |  0  |   0   |
|    8   |  0  |  0  |  1   |  0  |   0   |
|    9   |  1  |  0  |  0   |  0  |   0   |
| 10 (A) |  0  |  0  |  1   |  0  |   1   |
| 11 (B) |  0  |  0  |  0   |  0  |   1   |
| 12 (C) |  0  |  0  |  1   |  0  |   1   |
| 13 (D) |  0  |  0  |  0   |  0  |   1   |
| 14 (E) |  0  |  0  |  1   |  0  |   1   |
| 15 (F) |  0  |  0  |  0   |  0  |   1   |

### Question 2
Once again, review `bcdcheck2.vhd`. Based on your understanding of the code, what will the boolean equation be for each and every output?

A = x[0] , B = x[1] , C = x[2] , D = x[3]

max = A*B'*C'*D

min =  A'*B'*C'*D'

even = A'

lo3 = (A'*B'*C'*D) + (C'*D') * (A'*B')

noBCD = (D * C) + (D * C' * B)

### Question 3
Please give an elaborated explanation of the main difference between the two designs, `bcdcheck.vhd` and `bcdchec2.vhd`.

bcdcheck kollar igenom alla bitar x[3:0] för varje input och koden är skriven på de sättet att den inte har vilkor på inputen utan istället på 
bitarna som tilsammans skapar de olika inputsen.

bcdcheck2s bitar får deras platser i en vektor istället för att definera bitarna en i taget. Detta gör för en mer snygg lösning samt att man skriver i boolska utryck i bcdcheck2.


### Question 4
Screenshot the simulation result. Does the result of the simulation correspond to the table you filled in?

![Image description](bcd.png)


![Image description](Bcd2.PNG)

Ja värdena vi skrev in i tabellen stämmer med vad simulationen visar!
