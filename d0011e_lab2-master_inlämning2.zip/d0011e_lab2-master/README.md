# D0011E - Laboration 2
The lab specification is both on Canvas and in this repository. It is important that you make sure that all the questions in the lab specification has been answered in your README (this file). You don't have to use the same structure as we've created, but if you change it make it clear. **Make sure that you have pushed all the code you have written to the repo. Just because there is not a question about a part does not mean it is not needed to pass the lab.** If you want you can push the entire vivado project.

## Answers

### Question 1
See the definition of hieq3 in the lab specification. Add the value of heiq3 in the table.

|  Input | max | min | even | lo3 | noBCD | heiq3 |
|:------:|:---:|:---:|:----:|:---:|:-----:|:-----:|
|    0   |  0  |  1  |   1  |  1  |   0   |   0   |
|    1   |  0  |  0  |   0  |  1  |   0   |   0   |
|    2   |  0  |  0  |   1  |  1  |   0   |   0   |
|    3   |  0  |  0  |   0  |  0  |   0   |   1   |
|    4   |  0  |  0  |   1  |  0  |   0   |   1   |
|    5   |  0  |  0  |   0  |  0  |   0   |   1   |
|    6   |  0  |  0  |   1  |  0  |   0   |   1   |
|    7   |  0  |  0  |   0  |  0  |   0   |   1   |
|    8   |  0  |  0  |   1  |  0  |   0   |   1   |
|    9   |  1  |  0  |   0  |  0  |   0   |   1   |
| 10 (A) |  0  |  0  |   1  |  0  |   1   |   0   |
| 11 (B) |  0  |  0  |   0  |  0  |   1   |   0   |
| 12 (C) |  0  |  0  |   1  |  0  |   1   |   0   |
| 13 (D) |  0  |  0  |   0  |  0  |   1   |   0   |
| 14 (E) |  0  |  0  |   1  |  0  |   1   |   0   |
| 15 (F) |  0  |  0  |   0  |  0  |   1   |   0   |



### Question 2
What is the boolean equation for heiq3?

heiq3 = (A'·B'·C·D) + (A'·B'·C·D') + (A'·B·C'·D) + (A'·B·C·D') + (A'·B·C·D) + (A·B'·C'·D') + (A·B'·C'·D)

### Question 3
After modifying `bcdchec2.vhd` and the corresponding test bench, answer the following questions:
What types of signals are predfined in VHDL?  

 Både 0 cch 1 är föredefinerade signaler i VHDL vilket är digitala signaler. std_logic, std_logic_vector, bit och bit_vector är också fördefinerade signaler.

What are the differences between an Integer and a std_logic in VHDL?

 std_logic har ett definerat antal bits som bygger upp talet medans integer kan ha vilket bit djup som helst.
 
### Question 4
After creating `bcdcheck3.vhd` to use intermediate signals, compare `bcdcheck3.vhd` and `bcdcheck4.vhd` RTL schema. What are the differences and why do we want to you use intermediate signals?

skillanden är att om vi använder oss utav mellanliggande signaler så återanvänder vi signaler från lo3 samr noBCD för att få fram resultatet för hieq3 istället för att ha två
separata komperatorer för bara hieq3, detta skapar ett snabbare resultat.


### Question 5
When you reused the comparators you had to add other logic gates. Then, was it a good decision to remove the comparators?

Ja, eftersom att lägga till en logisk gate är snabbare än att ha 2 till komperatorer.

### Question 6
Try to change the order of code by moving hieq3 above the assignment of the signals. Does this change the behaviour?

Nej detta ändrade inget vilket betyder att orningen i vhdl inte spelar någon roll.

### Question 7
After implementing and testing part 2a) in the lab specification, has the synthesis tool optimized the RTL design in some way? How?
    
Ja den optimerade designen genom att byta ut alla AND grindar mot antingen OR grindar eller en lookup table, detta gör så att programmet optimeras pågrund av att en LUT enbart
tar upp en minnes slot för att beräkna funktionen.

### Question 8
Create a truth table for f, as defined in the lab specification part 2a), and verify the design by comparing the truth table from Question 1.

|  Input |  f  |
|:------:|:---:|
|    0   |  1  |
|    1   |  0  |
|    2   |  1  |
|    3   |  1  |
|    4   |  1  |
|    5   |  0  |
|    6   |  1  |
|    7   |  1  |
|    8   |  1  |
|    9   |  1  |
| 10 (A) |  0  |
| 11 (B) |  0  |
| 12 (C) |  1  |
| 13 (D) |  1  |
| 14 (E) |  0  |
| 15 (F) |  0  |



### Question 9
Show how you have minimized f to "fit" into the PLD cell you have implemented. Either you perform Karnaugh minimization or use boolean algebra.

Vi tog och börja med att göra ett truth table för funktionen sedan satte vi in värderna i en K-map, vi ringade sedan in nollorna pga att det blir lättare för då behöver vi inte 
göra ett extra steg, för när man ringar in nollor så ser man när f inte gäller och seadan är det bara att skicka med en etta i inv signalen för att invertera resultatet. 
Sedan tog vi ut delarana av ekvationen som vi fick utav de gruperade nollorna och satt ihop det till en funktion.

    resultat: (A·C) + (A'·C'·D)

https://imgur.com/a/bEJqLGI
(Länk till bild på k-map de gick inte att läga till den i projektet så gjorde så här istället).

### Question 10
Show the boolean equations for x3, x2, x1, x0 for part 4. How did you get to these boolean expressions? How did you assure yourself that these are correct? 

    y3 <= ((x(3) and '1') or (x(2) and '1') or (x(1) and '1')) xor '1';
    y2 <= (('0' and '0') or ('0' and '0') or x(2)) xor x(1);
    y1 <= ((x(1) and '1') or ('0' and '0') or ('0' and '1'))xor '0';
    y0 <= ((x(0) and '1') or ('0' and '1') or ('0' and '1')) xor '1';
    
Vi ställde upp binära ekvationer för både y och x sedan jämförde vi dom med varandra och försökte hitta samband, och sedan skrev vi ekvationen för den. 
Vi kollade att vi hade rätt genom att simulera ekvationerna med talen mellan 0-9 och kollade med en sanningstabell.