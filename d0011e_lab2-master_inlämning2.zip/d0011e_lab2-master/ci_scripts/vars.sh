CI_PROJECT="lab_2"
CI_TESTBENCH="bcdcheck2_tb"
